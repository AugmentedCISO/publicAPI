from setuptools import setup

setup(
    name='aciso',
    version='1',
    packages=['aciso'],
    url='',
    license='',
    author='EXCUBE',
    author_email='contact@excube.com',
    description='Augmented ciso APi rest package',
    install_requires=[
          'requests',
      ],
    zip_safe=False
)
